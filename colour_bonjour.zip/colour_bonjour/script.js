const root = document.documentElement;
const colorPicker = document.querySelector('#colorPicker');
//color picker gives us its value in hex so first we make it rgb

function setTheme(color) {
  // Converts hex to RGB 
  let r = 0,
    g = 0,
    b = 0
    hexa1 = 0;
    hpom =0;
  if (color.length == 4) {
    r = "0x" + color[1] + color[1];
    g = "0x" + color[2] + color[2];
    b = "0x" + color[3] + color[3];
    r1 = color[1] + color[1];
    g1 = color[2] + color[2];
    b1 = color[3] + color[3];
    hexa1 = "#"+color[1]+color[2]+color[3];
  } else if (color.length == 7) {
    r = "0x" + color[1] + color[2];
    g = "0x" + color[3] + color[4];
    b = "0x" + color[5] + color[6];
    r1 = color[1] + color[2];
    g1 = color[3] + color[4];
    b1 = color[5] + color[6];
    hex1 ="Default: "+"#"+color[1]+color[2]+color[3]+color[4]+color[5]+color[6];
  }
  document.getElementById("defaultHEX").innerHTML = hex1;
  
  r1 = parseInt(r1, 16);
  g1 = parseInt(g1, 16);
  b1 = parseInt(b1, 16);

  rgb1 = "Default: "+"RGB"+"("+r1+", "+g1+", "+b1+")";
  document.getElementById("defaultRGB").innerHTML = rgb1;
  // converts RGB to HSL
  r /= 255;
  g /= 255;
  b /= 255;
  rgb = 0;

  let cmin = Math.min(r, g, b),
    cmax = Math.max(r, g, b),
    delta = cmax - cmin,
    h = 0,
    s = 0,
    l = 0;

  if (delta == 0) h = 0;
  else if (cmax == r) h = ((g - b) / delta) % 6;
  else if (cmax == g) h = (b - r) / delta + 2;
  else h = (r - g) / delta + 4;

  h = Math.round(h * 60);

  if (h < 0) h += 360;

  l = (cmax + cmin) / 2;
  s = delta == 0 ? 0 : delta / (1 - Math.abs(2 * l - 1));
  s = +(s * 100).toFixed(1);
  l = +(l * 100).toFixed(1);
  hsl1 ="Default: "+"hsl("+h+", "+s+"%, "+l+"%)";
  document.getElementById("defaultHSL").innerHTML = hsl1;
 

  //HSL for colors done after the change

 
  hpom = h + 180;
  spom = s;
  lpom = l;
  if (hpom > 360) hpom -= 360;
  hsl2 = "Complement: "+"hsl("+hpom+", "+spom+"%, "+lpom+"%)";
  document.getElementById("complementHSL").innerHTML = hsl2;


  htri1 = h + 120;
  stri1 = s;
  ltri1 = l;
  if (htri1 > 360) htri1 -= 360;
  hsltri1 = "Triada1: "+"hsl("+htri1+", "+stri1+"%, "+ltri1+"%)";
  document.getElementById("triada1HSL").innerHTML = hsltri1;


  htri2 = h + 240;
  stri2 = s;
  ltri2 = l;
  if (htri2 > 360) htri2 -= 360;
  hsltri2 = "Triada2: "+"hsl("+htri2+", "+stri2+"%, "+ltri2+"%)";
  document.getElementById("triada2HSL").innerHTML = hsltri2;

  hana1 = h + 15;
  sana1 = s;
  lana1 = l;
  if (hana1 > 360) hana1 -= 360;
  hslana1 = "Analogous1: "+"hsl("+hana1+", "+sana1+"%, "+lana1+"%)";
  document.getElementById("analogous1HSL").innerHTML = hslana1;

  hana2 = h - 15;
  sana2 = s;
  lana2 = l;
  if (hana2 < 0) hana2 = 0;
  hslana2 = "Analogous2: "+"hsl("+hana2+", "+sana2+"%, "+lana2+"%)";
  document.getElementById("analogous2HSL").innerHTML = hslana2;

//RGB for colors done after the change

  const HSLToRGB = []; {
    spom /= 100;
    lpom /= 100;
    const k = n => (n + hpom / 30) % 12;
    const a = spom * Math.min(lpom, 1 - lpom);
    const f = n =>
      lpom - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)));
    HSLToRGB[0]= Math.round(255 * f(0));
    HSLToRGB[1]= Math.round(255 * f(8));
    HSLToRGB[2]= Math.round(255 * f(4));
  }
  tiskRGB = "Complement: "+"RGB"+"("+HSLToRGB[0]+", "+HSLToRGB[1]+", "+HSLToRGB[2]+")";
  document.getElementById("complementRGB").innerHTML = tiskRGB;

  const HSLToRGB1 = []; {
    stri1 /= 100;
    ltri1 /= 100;
    const k = n => (n + htri1 / 30) % 12;
    const a = stri1 * Math.min(ltri1, 1 - ltri1);
    const f = n =>
      ltri1 - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)));
    HSLToRGB1[0]= Math.round(255 * f(0));
    HSLToRGB1[1]= Math.round(255 * f(8));
    HSLToRGB1[2]= Math.round(255 * f(4));
  }
  tiskRGBtr1 = "Triada1: "+"RGB"+"("+HSLToRGB1[0]+", "+HSLToRGB1[1]+", "+HSLToRGB1[2]+")";
  document.getElementById("triada1RGB").innerHTML = tiskRGBtr1;

  const HSLToRGB2 = []; {
    stri2 /= 100;
    ltri2 /= 100;
    const k = n => (n + htri2 / 30) % 12;
    const a = stri2 * Math.min(ltri2, 1 - ltri2);
    const f = n =>
      ltri2 - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)));
    HSLToRGB2[0]= Math.round(255 * f(0));
    HSLToRGB2[1]= Math.round(255 * f(8));
    HSLToRGB2[2]= Math.round(255 * f(4));
  }
  tiskRGBtr2 = "Triada2: "+"RGB"+"("+HSLToRGB2[0]+", "+HSLToRGB2[1]+", "+HSLToRGB2[2]+")";
  document.getElementById("triada2RGB").innerHTML = tiskRGBtr2;

  const HSLToRGB3 = []; {
    sana1 /= 100;
    lana1 /= 100;
    const k = n => (n + hana1 / 30) % 12;
    const a = sana1 * Math.min(lana1, 1 - lana1);
    const f = n =>
      lana1 - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)));
    HSLToRGB3[0]= Math.round(255 * f(0));
    HSLToRGB3[1]= Math.round(255 * f(8));
    HSLToRGB3[2]= Math.round(255 * f(4));
  }
  tiskRGBana1 = "Analogous1: "+"RGB"+"("+HSLToRGB3[0]+", "+HSLToRGB3[1]+", "+HSLToRGB3[2]+")";
  document.getElementById("analogous1RGB").innerHTML = tiskRGBana1;

  const HSLToRGB4 = []; {
    sana2 /= 100;
    lana2 /= 100;
    const k = n => (n + hana2 / 30) % 12;
    const a = sana1 * Math.min(lana2, 1 - lana2);
    const f = n =>
      lana2 - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)));
    HSLToRGB4[0]= Math.round(255 * f(0));
    HSLToRGB4[1]= Math.round(255 * f(8));
    HSLToRGB4[2]= Math.round(255 * f(4));
  }
  tiskRGBana2 = "Analogous2: "+"RGB"+"("+HSLToRGB4[0]+", "+HSLToRGB4[1]+", "+HSLToRGB4[2]+")";
  document.getElementById("analogous2RGB").innerHTML = tiskRGBana2;

  //HEX for colors done after the change

  rpom = HSLToRGB[0].toString(16);
  gpom = HSLToRGB[1].toString(16);
  bpom = HSLToRGB[2].toString(16);
  if (rpom.length == 1)
      rpom = "0" + rpom;
  if (gpom.length == 1)
      gpom = "0" + gpom;
  if (bpom.length == 1)
      bpom = "0" + bpom;
  hex2 = "Complement: "+"#"+rpom+gpom+bpom;

  document.getElementById("complementHEX").innerHTML = hex2;


  rtri1 = HSLToRGB1[0].toString(16);
  gtri1 = HSLToRGB1[1].toString(16);
  btri1 = HSLToRGB1[2].toString(16);
  if (rtri1.length == 1)
      rtri1 = "0" + rtri1;
  if (gtri1.length == 1)
      gtri1 = "0" + gtri1;
  if (btri1.length == 1)
      btri1 = "0" + btri1;
  hextri1 = "Triada1: "+"#"+rtri1+gtri1+btri1;

  document.getElementById("triada1HEX").innerHTML = hextri1;

  rtri2 = HSLToRGB2[0].toString(16);
  gtri2 = HSLToRGB2[1].toString(16);
  btri2 = HSLToRGB2[2].toString(16);
  if (rtri2.length == 1)
      rtri2 = "0" + rtri2;
  if (gtri2.length == 1)
      gtri2 = "0" + gtri2;
  if (btri2.length == 1)
      btri2 = "0" + btri2;
  hextri2 = "Triada2: "+"#"+rtri2+gtri2+btri2;

  document.getElementById("triada2HEX").innerHTML = hextri2;

  rana1 = HSLToRGB3[0].toString(16);
  gana1 = HSLToRGB3[1].toString(16);
  bana1 = HSLToRGB3[2].toString(16);
  if (rana1.length == 1)
      rana1 = "0" + rana1;
  if (gana1.length == 1)
      gana1 = "0" + gtri1;
  if (bana1.length == 1)
      bana1 = "0" + btri1;
  hexana1 = "Analogous1: "+"#"+rana1+gana1+bana1;

  document.getElementById("analogous1HEX").innerHTML = hexana1;

  rana2 = HSLToRGB4[0].toString(16);
  gana2 = HSLToRGB4[1].toString(16);
  bana2 = HSLToRGB4[2].toString(16);
  if (rana2.length == 1)
      rana2 = "0" + rana2;
  if (gana2.length == 1)
      gana2 = "0" + gtri2;
  if (bana2.length == 1)
      bana2 = "0" + btri2;
  hexana2 = "Analogous2: "+"#"+rana2+gana2+bana2;

  document.getElementById("analogous2HEX").innerHTML = hexana2;




 root.style.setProperty(`--primary-color-h`, h);
 root.style.setProperty(`--primary-color-s`, s + "%");
 root.style.setProperty(`--primary-color-l`, l + "%");
}

colorPicker.addEventListener("change", watchColorPicker, false);

function watchColorPicker(event) {
 setTheme(event.target.value);
}

function myColor() {
// Get the value return by color picker
var color = document.getElementById('colorPicker').value;
// Set the color as background

// Take the hex code
document.getElementById('box').value = color;
}

// When user clicks over color picker,
// myColor() function is called
document.getElementById('colorPicker')
.addEventListener('input', myColor);